<?php
$a=[1,2,3,4];
echo arr2str($a);