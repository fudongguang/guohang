<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
    <title>hello <?php echo ($name); ?></title>
</head>
<body>
hello, <?php echo ($name); ?>!
</body>
</html>