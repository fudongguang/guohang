<?php
/**
 * Created by PhpStorm.
 * User: fudongguang
 * Date: 14-6-9
 * Time: 下午1:54
 */

function aa(){
    return 'sdf';
}